/*
 * hello.c
 * Matthew Tay Han Yang (mhtay)
 * Deeptaanshu Kumar (deeptaan)
 * Kevin Brennan (kbrennan)
 */

# include<stdio.h> 

int main () {
	
	// prints to default stdout FILE stream
	fprintf(stdout, "Hello world!\n");
	
	// exit status 0 (success) 	
	return 0;  
}

